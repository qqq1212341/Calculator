//
//  ViewController.swift
//  My_Caculator
//
//  Created by 이희준 on 2021/07/06.
//

import UIKit

class ViewController: UIViewController {
    
    var Value: String = "0"
    @IBOutlet var presentValueLabel: UILabel!
    @IBOutlet var saveValueLabel: UILabel!
    var Index: Int = 0
    var SaveValue: String = "0"


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("Main")
        view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        presentValueLabel.text = String(Value)
        presentValueLabel.textAlignment = .right
        presentValueLabel.font = UIFont.boldSystemFont(ofSize: 50)
        saveValueLabel.text = String(Value)
        saveValueLabel.textAlignment = .right
        saveValueLabel.font = UIFont.boldSystemFont(ofSize: 23)
        }
    
    
    @IBAction func number_0(_ sender: UIButton){
        if Double(Value)! == 0{
            Value = "0"
        }
        else{
        Value = Value+"0"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_1(_ sender: UIButton){
        //Value = Int(String(Value)+"1")!
        if Double(Value)! == 0{
            Value = "1"
        }
        else{
        Value = Value+"1"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_2(_ sender: UIButton){
        //Value = Int(String(Value)+"2")!
        if Double(Value)! == 0{
            Value = "2"
        }
        else{
        Value = Value+"2"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_3(_ sender: UIButton){
        //Value = Int(String(Value)+"3")!
        if Double(Value)! == 0{
            Value = "3"
        }
        else{
        Value = Value+"3"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_4(_ sender: UIButton){
        //Value = Int(String(Value)+"4")!
        if Double(Value)! == 0{
            Value = "4"
        }
        else{
        Value = Value+"4"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_5(_ sender: UIButton){
        //Value = Int(String(Value)+"5")!
        if Double(Value)! == 0{
            Value = "5"
        }
        else{
        Value = Value+"5"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_6(_ sender: UIButton){
        //Value = Int(String(Value)+"6")!
        if Double(Value)! == 0{
            Value = "6"
        }
        else{
        Value = Value+"6"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_7(_ sender: UIButton){
        //Value = Int(String(Value)+"7")!
        if Double(Value)! == 0{
            Value = "7"
        }
        else{
        Value = Value+"7"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_8(_ sender: UIButton){
        //Value = Int(String(Value)+"8")!
        if Double(Value)! == 0{
            Value = "8"
        }
        else{
        Value = Value+"8"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func number_9(_ sender: UIButton){
        //Value = Int(String(Value)+"9")!
        if Double(Value)! == 0{
            Value = "9"
        }
        else{
        Value = Value+"9"
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func Reset(_ sender: UIButton){
        Value = "0"
        presentValueLabel.text = String(Value)
    }
    @IBAction func Delete(_ sender: UIButton){
        //Value = String(Int(exactly: Int(Value) ?? 0/10)!)
        if Value.count == 1{
            Value = "0"
        }else{
            let endIdx: String.Index = Value.index(Value.startIndex, offsetBy: Value.count - 2)
            Value = String(Value[...endIdx])
        }
        print(Value)
        presentValueLabel.text = String(Value)
    }
    @IBAction func Dot(_ sender: UIButton){
        /*let endIndex = Value.index(before: Value.endIndex)
        let last = Value[endIndex]
        if last != "."*/
        if Value.contains(".") {
        } else{
            Value = Value + "."
        }
        presentValueLabel.text = String(Value)
    }
    @IBAction func Plus(_ sender: UIButton){
        SaveValue = Value
        Value = "0"
        print(SaveValue)
        presentValueLabel.text = String(Value)
        saveValueLabel.text = String(SaveValue)
        Index = 0
    }
    @IBAction func Minus(_ sender: UIButton){
        SaveValue = Value
        Value = "0"
        print(SaveValue)
        presentValueLabel.text = String(Value)
        saveValueLabel.text = String(SaveValue)
        Index = 1
    }

    @IBAction func Multi(_ sender: UIButton){
        SaveValue = Value
        Value = "0"
        print(SaveValue)
        presentValueLabel.text = String(Value)
        saveValueLabel.text = String(SaveValue)
        Index = 2
    }

    @IBAction func Divide(_ sender: UIButton){
        SaveValue = Value
        Value = "0"
        print(SaveValue)
        presentValueLabel.text = String(Value)
        saveValueLabel.text = String(SaveValue)
        Index = 3
    }

    
    @IBAction func equal(_sender: UIButton){
        Value = Calculate(Index: Index, num1: SaveValue, num2: Value)
        /*if Double(Value) == Double(Int(Value)!) {
            presentValueLabel.text = String(Int(Value)!)
        }*/
        presentValueLabel.text = String(Value)
        print(Value)
    }
    
    
    func Calculate(Index: Int, num1: String, num2: String) -> String{
        if Index == 0{
            let value : String = String(Double(num1)! + Double(num2)!)
            return value
        }
        else if Index == 1{
            let value : String = String(Double(num1)! - Double(num2)!)
            return value
        }
        else if Index == 2{
            let value : String = String(Double(num1)! * Double(num2)!)
            return value
        }
        else if Index == 3{
            if num2 == "0"{
                return "0"
            }
            let value : String = String(Double(num1)! / Double(num2)!)
            return value
        }
        presentValueLabel.text = "error"
        return "error"
    }


//    func presentValue(_ sender: UILabel){
//        print(Value)
//        presentValueLabel.text = String(Value)
//        }
    

    
}

