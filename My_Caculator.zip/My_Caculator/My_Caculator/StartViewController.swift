//
//  StartViewController.swift
//  My_Caculator
//
//  Created by 이희준 on 2021/07/06.
//

import UIKit
import Lottie

class StartViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        view.backgroundColor = .white
        view.addSubview(animationView)
        animationView.center = view.center
        
        //애니메이션 실행
        animationView.play{ (finish) in
            print("애니메이션 끝")
        }
        
        dismiss(animated: false, completion: nil)
        
        
        
    }

    let animationView: AnimationView = {
        let animView = AnimationView(name: "50716-calculator")
        animView.frame = CGRect(x:0,y:0,width: 500, height: 500)
        animView.contentMode = .scaleAspectFill

        return animView
    }()


}
